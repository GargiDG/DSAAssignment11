import java.util.Arrays;
public class DSA11Q3 {

	    public static int missingNumber(int[] nums) {
	        Arrays.sort(nums);
	        int s = 0, e = nums.length - 1;

	        while (s <= e) {
	            int mid = s + (e - s) / 2;
	            if (nums[mid] == mid) {
	                s = mid + 1;
	            } else {
	                e = mid - 1;
	            }
	        }
	        return s;
	    }

	    public static void main(String[] args) {
	        int[] nums = {9,6,4,2,3,5,7,0,1};

	        int missingNumber = missingNumber(nums);
	        System.out.println("Missing number: " + missingNumber);
	    }
	}
