import java.util.Arrays;
public class DSA11Q7 {

	    public static int[] searchRange(int[] nums, int target) {
	        int[] result = {-1, -1};
	        int leftIndex = findIndex(nums, target, true);

	        if (leftIndex == -1) {
	            return result;
	        }

	        int rightIndex = findIndex(nums, target, false);

	        result[0] = leftIndex;
	        result[1] = rightIndex;
	        return result;
	    }

	    private static int findIndex(int[] nums, int target, boolean left) {
	        int index = -1;
	        int leftPtr = 0;
	        int rightPtr = nums.length - 1;

	        while (leftPtr <= rightPtr) {
	            int mid = leftPtr + (rightPtr - leftPtr) / 2;

	            if (nums[mid] == target) {
	                index = mid;

	                if (left) {
	                    rightPtr = mid - 1;
	                } else {
	                    leftPtr = mid + 1;
	                }
	            } else if (nums[mid] < target) {
	                leftPtr = mid + 1;
	            } else {
	                rightPtr = mid - 1;
	            }
	        }

	        return index;
	    }

	    public static void main(String[] args) {
	        int[] nums = {5, 7, 7, 8, 8, 10};
	        int target = 8;
	        int[] result = searchRange(nums, target);
	        System.out.println("Range: " + Arrays.toString(result));
	    }
	}
